﻿namespace alternatestreams;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine(
            "There's no CLR code to access alternate data streams. "
                + "Has to be done using Win32 native calls!"
        );
    }
}
